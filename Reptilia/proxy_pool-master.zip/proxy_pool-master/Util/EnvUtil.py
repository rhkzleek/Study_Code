# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     EnvUtil
   Description :   环境相关
   Author :        J_hao
   date：          2017/9/18
-------------------------------------------------
   Change Activity:
                   2017/9/18: 区分Python版本
-------------------------------------------------
"""
__author__ = 'J_hao'

import sys

PY3 = sys.version_info >= (3,)